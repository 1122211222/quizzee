package com.example.quizapp

import kotlin.math.min

object Constants {
    const val USER_NAME: String = "user_name"
    const val TOTAL_QUESTIONS: String = "total_questions"
    const val CORRECT_ANSWERS: String = "correct_answers"

    fun getQuestions(category: String?): ArrayList<Question> {
        val allQuestions = ArrayList<Question>()
        category?.let {
            when (it) {
                "Geography" -> allQuestions.addAll(getGeographyQuestions())
                "Science" -> allQuestions.addAll(getScienceQuestions())
                "Math" -> allQuestions.addAll(getMathQuestions())
                else -> {
                    allQuestions.addAll(getGeographyQuestions())
                    allQuestions.addAll(getScienceQuestions())
                    allQuestions.addAll(getMathQuestions())
                }
            }
        }
        allQuestions.shuffle()

        // Ensure no question is repeated
        val distinctQuestions = ArrayList<Question>()
        val uniqueIds = HashSet<Int>()
        for (question in allQuestions) {
            if (uniqueIds.add(question.id)) {
                distinctQuestions.add(question)
            }
            if (distinctQuestions.size >= 10) {
                break
            }
        }
        return distinctQuestions
    }



    fun getGeographyQuestions(): ArrayList<Question> {
            val geographyQuestions = ArrayList<Question>()

            geographyQuestions.add(
                Question(
                    1,
                    "Which of the following is the capital city of France?",
                    R.drawable.earth,
                    "Paris",
                    "London",
                    "Berlin",
                    "Madrid",
                    1
                )
            )
            geographyQuestions.add(
                Question(
                    2,
                    "What is the longest river in the world?",
                    R.drawable.earth,
                    "Amazon River",
                    "Nile River",
                    "Yangtze River",
                    "Mississippi River",
                    1
                )
            )
            geographyQuestions.add(
                Question(
                    3,
                    "Which is the smallest continent by land area?",
                    R.drawable.earth,
                    "Europe",
                    "Australia",
                    "South America",
                    "Antarctica",
                    2
                )
            )
            geographyQuestions.add(
                Question(
                    4,
                    "What is the capital of Canada?",
                    R.drawable.earth,
                    "Toronto",
                    "Ottawa",
                    "Montreal",
                    "Vancouver",
                    2
                )
            )
            // Add more geography questions here...

            // Add more geography questions here

            return geographyQuestions
        }

        fun getScienceQuestions(): ArrayList<Question> {
            val scienceQuestions = ArrayList<Question>()

            scienceQuestions.add(
                Question(
                    1,
                    "Which of the following is the smallest bone in the human body?",
                    R.drawable.science,
                    "Femur",
                    "Tibia",
                    "Cochlea",
                    "Radius",
                    3
                )
            )
            // Add more science questions here

            return scienceQuestions
        }

        fun getMathQuestions(): ArrayList<Question> {
            val mathQuestions = ArrayList<Question>()

            mathQuestions.add(
                Question(
                    1,
                    "What is the value of 2 + 2?",
                    R.drawable.maths,
                    "3",
                    "4",
                    "5",
                    "6",
                    2
                )
            )
            mathQuestions.add(
                Question(
                    2,
                    "What is the square root of 64?",
                    R.drawable.maths,
                    "6",
                    "8",
                    "10",
                    "12",
                    2
                )
            )
            mathQuestions.add(
                Question(
                    3,
                    "What is the result of 5 * 7?",
                    R.drawable.maths,
                    "30",
                    "35",
                    "40",
                    "45",
                    3
                )
            )
            mathQuestions.add(
                Question(
                    4,
                    "What is the value of 10 - 3?",
                    R.drawable.maths,
                    "5",
                    "6",
                    "7",
                    "8",
                    3
                )
            )
            // Add more math questions here...

            return mathQuestions
        }

    }
