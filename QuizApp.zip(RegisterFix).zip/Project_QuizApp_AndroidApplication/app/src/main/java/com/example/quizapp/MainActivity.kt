package com.example.quizapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvWelcome = findViewById<TextView>(R.id.tv_welcome)
        val btnGeography = findViewById<MaterialButton>(R.id.btn_geography)
        val btnMath = findViewById<MaterialButton>(R.id.btn_math)
        val btnScience = findViewById<MaterialButton>(R.id.btn_science)
        val btnRandom = findViewById<MaterialButton>(R.id.btn_random)
        val ivMenu = findViewById<ImageView>(R.id.iv_menu)
        val sharedPreferences = getSharedPreferences("UserDetails", Context.MODE_PRIVATE)
        val storedName = sharedPreferences.getString("Username", "")

        // Set welcome message
        val username = storedName
        tvWelcome.text = "Welcome, $username"

        // Set onClickListener for buttons
        btnGeography.setOnClickListener {
            startQuizQuestionActivity("Geography")
        }

        btnMath.setOnClickListener {
            startQuizQuestionActivity("Math")
        }

        btnScience.setOnClickListener {
            startQuizQuestionActivity("Science")
        }

        btnRandom.setOnClickListener {
            startQuizQuestionActivity("Random")
        }

        // Set onClickListener for menu icon
        ivMenu.setOnClickListener {
            // Handle menu click (e.g., open menu with logout and profile)
            openMenu(ivMenu)
        }
    }

    private fun getUsernameFromSharedPreferences(): String {
        // Implement logic to get username from SharedPreferences
        return "User" // Example username
    }

    private fun startQuizQuestionActivity(category: String) {
        val intent = Intent(this, QuizQuestionActivity::class.java)
        intent.putExtra("CATEGORY", category)
        startActivity(intent)
    }

    private fun openMenu(ivMenu: ImageView) {
        val popupMenu = PopupMenu(this, ivMenu)
        popupMenu.menuInflater.inflate(R.menu.side_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {

                R.id.menu_logout -> {
                    // Clear user session
                    clearUserSession()

                    // Navigate to login screen
                    navigateToLoginScreen()
                    true
                }

                else -> false
            }
        }

        popupMenu.show()
    }

    private fun clearUserSession() {
        // Clear user session, such as removing saved credentials or tokens
        // Use the same key used during login
        val sharedPreferences = getSharedPreferences("UserDetails", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }


    private fun navigateToLoginScreen() {
        // Navigate to the login screen
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish() // Close MainActivity to prevent the user from navigating back
    }


    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


}
