package com.example.quizapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        usernameEditText = findViewById(R.id.et_username)
        emailEditText = findViewById(R.id.et_email)
        passwordEditText = findViewById(R.id.et_password)
        startButton = findViewById(R.id.btn_start)

        startButton.setOnClickListener {
            registerUser()
        }
    }

    private fun registerUser() {
        val username = usernameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        if (!isEmailValid(email)) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
            return
        }

        // Store registration details in local storage (SharedPreferences)
        val sharedPreferences = getSharedPreferences("UserDetails", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("Username", username)
        editor.putString("Email", email)
        editor.putString("Password", password)
        editor.apply()

        // Print the stored values
        val storedUsername = sharedPreferences.getString("Username", "")
        val storedEmail = sharedPreferences.getString("Email", "")
        val storedPassword = sharedPreferences.getString("Password", "")
        println("Stored Username: $storedUsername")
        println("Stored Email: $storedEmail")
        println("Stored Password: $storedPassword")

        // Show success alert
        AlertDialog.Builder(this)
            .setTitle("Success")
            .setMessage("You have been successfully registered!")
            .setPositiveButton("OK") { _, _ ->
                // Clear the EditText fields
                usernameEditText.text.clear()
                emailEditText.text.clear()
                passwordEditText.text.clear()

                // Navigate to MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
            .show()
    }

    private fun isEmailValid(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}
