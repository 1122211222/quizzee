package com.example.quizapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class SplashScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        val logoImageView = findViewById<ImageView>(R.id.logoImageView)

        // Show the logo before starting the animation


        // Start animation after a delay
        val fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.bottom_animation)
        Handler(Looper.getMainLooper()).postDelayed({
            logoImageView.startAnimation(fadeInAnimation)
            logoImageView.visibility = ImageView.VISIBLE
        }, ANIMATION_DELAY)

        // Redirect after a delay
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = if (checkIfUserIsLoggedIn()) {
                Intent(this, MainActivity::class.java)
            } else {
                Intent(this, LoginActivity::class.java)
            }
            startActivity(intent)
            finish()
        }, ANIMATION_DELAY + SPLASH_SCREEN_DELAY)
    }

    private fun checkIfUserIsLoggedIn(): Boolean {
        // Check if the user is logged in based on your authentication mechanism
        // You can use SharedPreferences, database, or any other method to determine this
        // For example, if using SharedPreferences:
        val sharedPreferences = getSharedPreferences("UserDetails", Context.MODE_PRIVATE)
        return sharedPreferences.contains("Username") && sharedPreferences.contains("Password")
    }

    companion object {
        private const val ANIMATION_DELAY = 2000L // 2 seconds delay for animation
        private const val SPLASH_SCREEN_DELAY = 2000L // 2 seconds delay for splash screen
    }
}
